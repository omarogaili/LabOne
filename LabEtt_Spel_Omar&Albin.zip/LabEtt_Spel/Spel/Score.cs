﻿namespace Spel;

public class Score
{
    public int score { get; set; } // saving the score
    public int scoreId { get; set; }  // Id
    public int userId { get; set; } // FK for user

}
