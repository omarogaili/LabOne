﻿namespace Spel;

public class User
{
    public String userName { get; set; } // saving the user name 
    public int userId { get; set; } // create an ID for each user
}
