﻿namespace Spel;
public class HighScore
{
    
}
